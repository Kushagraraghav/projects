package taskmanager;

import java.time.LocalDate;

public class Task {
    private int id;
    private String title;
    private String category;
    private LocalDate dueDate;
    private boolean isDone;

    public Task(int id, String title, String category, LocalDate dueDate) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.dueDate = dueDate;
        this.isDone = false;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getCategory() { return category; }
    public LocalDate getDueDate() { return dueDate; }
    public boolean isDone() { return isDone; }

    public void setDone(boolean done) { isDone = done; }

    @Override
    public String toString() {
        return id + " | " + title + " | " + category + " | Due: " + dueDate + " | Done: " + isDone;
    }
}
