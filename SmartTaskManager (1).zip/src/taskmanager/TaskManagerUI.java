package taskmanager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDate;

public class TaskManagerUI {
    private TaskManager manager = new TaskManager();

    public void createUI() {
        JFrame frame = new JFrame("Smart Task Manager");
        frame.setSize(500, 400);
        frame.setLayout(new BorderLayout());

        JTextField titleField = new JTextField();
        JTextField categoryField = new JTextField();
        JTextField dateField = new JTextField("YYYY-MM-DD");

        JTextArea display = new JTextArea();
        JButton addButton = new JButton("Add Task");

        addButton.addActionListener((ActionEvent e) -> {
            try {
                String title = titleField.getText();
                String category = categoryField.getText();
                LocalDate dueDate = LocalDate.parse(dateField.getText());
                Task task = new Task(manager.getAllTasks().size() + 1, title, category, dueDate);
                manager.addTask(task);
                display.append(task.toString() + "\n");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Invalid input! " + ex.getMessage());
            }
        });

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Title:")); panel.add(titleField);
        panel.add(new JLabel("Category:")); panel.add(categoryField);
        panel.add(new JLabel("Due Date:")); panel.add(dateField);
        panel.add(addButton);

        frame.add(panel, BorderLayout.NORTH);
        frame.add(new JScrollPane(display), BorderLayout.CENTER);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new TaskManagerUI().createUI();
        new ReminderThread().start();
    }
}
