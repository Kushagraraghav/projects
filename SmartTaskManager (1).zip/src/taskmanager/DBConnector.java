package taskmanager;

import java.sql.*;

public class DBConnector {
    private Connection conn;

    public DBConnector() throws SQLException {
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taskdb", "root", "yourpassword");
    }

    public void insertTask(Task task) throws SQLException {
        String sql = "INSERT INTO tasks (title, category, due_date, is_done) VALUES (?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, task.getTitle());
        ps.setString(2, task.getCategory());
        ps.setDate(3, Date.valueOf(task.getDueDate()));
        ps.setBoolean(4, task.isDone());
        ps.executeUpdate();
    }
}
