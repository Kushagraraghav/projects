package taskmanager;

public class ReminderThread extends Thread {
    public void run() {
        while (true) {
            System.out.println("🔔 Reminder: Check your tasks!");
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                System.out.println("Reminder stopped.");
            }
        }
    }
}
